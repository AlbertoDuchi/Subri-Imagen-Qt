/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *imagen;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *btnprimero;
    QPushButton *btnanterior;
    QPushButton *btnsiguiente;
    QPushButton *btnultimo;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1158, 600);
        imagen = new QLabel(Widget);
        imagen->setObjectName(QString::fromUtf8("imagen"));
        imagen->setGeometry(QRect(90, 40, 431, 371));
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(120, 450, 395, 32));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        btnprimero = new QPushButton(layoutWidget);
        btnprimero->setObjectName(QString::fromUtf8("btnprimero"));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        btnprimero->setFont(font);

        horizontalLayout->addWidget(btnprimero);

        btnanterior = new QPushButton(layoutWidget);
        btnanterior->setObjectName(QString::fromUtf8("btnanterior"));
        btnanterior->setFont(font);

        horizontalLayout->addWidget(btnanterior);

        btnsiguiente = new QPushButton(layoutWidget);
        btnsiguiente->setObjectName(QString::fromUtf8("btnsiguiente"));
        btnsiguiente->setFont(font);

        horizontalLayout->addWidget(btnsiguiente);

        btnultimo = new QPushButton(layoutWidget);
        btnultimo->setObjectName(QString::fromUtf8("btnultimo"));
        btnultimo->setFont(font);

        horizontalLayout->addWidget(btnultimo);

        plainTextEdit = new QPlainTextEdit(Widget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(700, 140, 381, 311));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        imagen->setText(QApplication::translate("Widget", "TextLabel", nullptr));
        btnprimero->setText(QApplication::translate("Widget", "|<", nullptr));
        btnanterior->setText(QApplication::translate("Widget", "<", nullptr));
        btnsiguiente->setText(QApplication::translate("Widget", ">", nullptr));
        btnultimo->setText(QApplication::translate("Widget", ">|", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
