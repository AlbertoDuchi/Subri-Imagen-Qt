#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPixmap>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

struct imagen {
    int id;
    QString archivo;
    QString nombre;
};

struct Nodo {
    imagen dato;
    Nodo* siguiente;
    Nodo* atras;
};

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_btnprimero_clicked();
    void on_btnanterior_clicked();
    void on_btnsiguiente_clicked();
    void on_btnultimo_clicked();

private:
    Ui::Widget *ui;
    QPixmap pixmap;
    Nodo *primero=NULL;
    Nodo *ultimo=NULL;
    imagen Imagen;
    int imagenInicial=1;
    int imagenFinal=1;
    void insertarNodo(Nodo *&primero, Nodo *&ultimo, imagen dato);
    void mostrarListaAsc(Nodo *primero);
    void mostrarListaDesc(Nodo *primero, Nodo *ultimo);
    void subirImagen(const QString &nombreArchivo);
    void buscarNodo(Nodo *primero, int datoBuscado);
};

#endif // WIDGET_H
