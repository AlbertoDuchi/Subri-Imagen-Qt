#include "widget.h"
#include "ui_widget.h"

#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    QString nombreArchivo = "imagenes.txt";
    QString ruta = "/Users/RUSO/Downloads/EjemploNodo/";
    QFile archivo(ruta + nombreArchivo);
    QTextStream io;

    setWindowFlags(windowFlags() & ~Qt::WindowMinimizeButtonHint & ~Qt::WindowMaximizeButtonHint);
    setWindowTitle("Ejemplo");

    // Definir el espacio de trabajo
    pixmap = QPixmap(500, 800);
    // Rellenar el espacio de trabajo - Fondo
    pixmap.fill(Qt::white);
    // Las caracteristicas definidas en el espacio de trabajo
    ui->imagen->setPixmap(pixmap);

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", archivo.errorString());
    } else {
        io.setDevice(&archivo);
        int contador=0;
        while (!io.atEnd()) {
            QString linea = io.readLine();
            QStringList datos = linea.split(",");
            Imagen.id = datos[0].toInt();
            Imagen.archivo = datos[1];
            Imagen.nombre = datos[2];
            insertarNodo(primero, ultimo, Imagen);
            qDebug() << datos[0] << " " << datos[1];
            contador++;
        }
        if(contador>0){
            imagenInicial=1;
            imagenFinal=contador;
            buscarNodo(primero, imagenInicial);
            ui->btnprimero->setEnabled(false);
            mostrarListaAsc(primero);
        }
        archivo.close();
    }
}

Widget::~Widget()
{
    delete ui;
}

void Widget::insertarNodo(Nodo *&primero, Nodo *&ultimo, imagen dato) {
    Nodo *nuevoNodo = new Nodo();
    nuevoNodo->dato = dato;
    if (primero == NULL) {
        primero = nuevoNodo;
        primero->siguiente = NULL;
        primero->atras = NULL;
        ultimo = primero;
    } else {
        ultimo->siguiente = nuevoNodo;
        nuevoNodo->siguiente = NULL;
        nuevoNodo->atras = ultimo;
        ultimo = nuevoNodo;
    }
}

void Widget::mostrarListaAsc(Nodo *primero) {
    Nodo *actual = primero;
    if (primero != NULL) {
        while (actual != NULL) {
            ui->plainTextEdit->appendPlainText(actual->dato.nombre);
            qDebug() << actual->dato.id << " " << actual->dato.archivo << " " << actual->dato.nombre << "\n";
            actual = actual->siguiente;
        }
    } else {
        qDebug() << "La lista está vacía\n";
    }
}

void Widget::mostrarListaDesc(Nodo *primero, Nodo *ultimo) {
    Nodo *actual = ultimo;
    if (primero != NULL) {
        while (actual != NULL) {
            ui->plainTextEdit->appendPlainText(actual->dato.nombre);
            qDebug() << actual->dato.id << " " << actual->dato.archivo << " " << actual->dato.nombre << "\n";
            actual = actual->atras;
        }
    } else {
        qDebug() << "La lista está vacía\n";
    }
}

void Widget::subirImagen(const QString &nombreArchivo) {
    // Verificar que se haya seleccionado un archivo
    if (nombreArchivo.isEmpty()) {
        QMessageBox::information(this, "Aviso", "Error, no seleccionó una imagen");
        return;
    }

    ui->imagen->setPixmap(QPixmap(nombreArchivo));
    ui->imagen->setScaledContents(true);
}

void Widget::on_btnprimero_clicked() {
    // Implementar lógica para mostrar la primera imagen
    imagenInicial=1;
    buscarNodo(primero, imagenInicial);
    ui->btnprimero->setEnabled(false);
}

void Widget::on_btnanterior_clicked() {
    // Implementar lógica para mostrar la imagen anterior
    imagenInicial--;
    if(imagenInicial>=1){
        buscarNodo(primero, imagenInicial);
        ui->btnprimero->setEnabled(true);
        ui->btnultimo->setEnabled(true);
    }else{
        imagenInicial=1;
         ui->btnprimero->setEnabled(false);
    }
}

void Widget::on_btnsiguiente_clicked() {
    // Implementar lógica para mostrar la siguiente imagen
    imagenInicial++;
    ui->btnprimero->setEnabled(true);
    ui->btnultimo->setEnabled(true);
    if(imagenInicial<=imagenFinal){
        buscarNodo(primero, imagenInicial);
    }else{
        imagenInicial=imagenFinal;
        ui->btnultimo->setEnabled(false);
    }
}

void Widget::on_btnultimo_clicked() {
    // Implementar lógica para mostrar la última imagen
    //imagenInicial=1;
    buscarNodo(primero, imagenFinal);
    ui->btnprimero->setEnabled(true);
}

void Widget::buscarNodo(Nodo *primero, int datoBuscado) {
    Nodo *actual = primero;
    QString nombreArchivo;
    bool encontrado = false;

    if (primero != NULL) {
        while (actual != NULL && !encontrado) {
            if (actual->dato.id == datoBuscado) {
                nombreArchivo = actual->dato.archivo;
                qDebug() << datoBuscado << " Dato encontrado\n";
                encontrado = true;
                subirImagen(nombreArchivo);
            }
            actual = actual->siguiente;
        }
        if (!encontrado) {
            qDebug() << datoBuscado << " Dato no encontrado\n";
        }
    } else {
        qDebug() << "La lista se encuentra vacía\n";
    }
}
